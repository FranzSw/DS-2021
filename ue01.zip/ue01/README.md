# Exercise Sheet 1

Abgabe von Tamino Bauknecht, Franz Sauerwald, Benedikt Weber

## Ex1

For exercise one, to download new images (remove the old ones and) execute the ex1.py script

Find the required metrics in `images/_meta.txt`

(requests library required)

## Ex2

Execute the ex2.py script to see the fetched data for 4 search requests in the `blub` folder.
